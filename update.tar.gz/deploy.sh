#!/bin/bash

# Load .env file
set -o allexport
source .env
set +o allexport

APP_NAME=markt-app
REMOTE_PATH=/home/$SSH_USER/$APP_NAME

echo "🛠 Baue Assets lokal..."
npm ci
npm run build

TARFILE=update.tar.gz

echo "📦 Erstelle $TARFILE..."
tar --exclude=node_modules --exclude=vendor --exclude=storage/logs --exclude=.git -czf $TARFILE .

echo "📤 Übertrage nach $SSH_SERVER..."
scp -P "$SSH_PORT" "$TARFILE" "$SSH_USER@$SSH_SERVER:/home/$SSH_USER/"

echo "🚀 Aktualisiere remote..."
ssh -p "$SSH_PORT" "$SSH_USER@$SSH_SERVER" "
    cd /home/$SSH_USER &&
    rm -rf $APP_NAME.old &&
    mv $APP_NAME $APP_NAME.old || true &&
    mkdir $APP_NAME &&
    tar -xzf $TARFILE -C $APP_NAME &&
    rm $TARFILE
"

echo "✅ Fertig! Projekt wurde übertragen."