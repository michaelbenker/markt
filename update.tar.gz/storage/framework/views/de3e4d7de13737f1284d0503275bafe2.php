<tr>
    <td>
        <table class="footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
            <tr>
                <td class="content-cell" align="center">
                    <p style="text-align: left; font-size: 0.7em;">
                        <b><?php echo new \Illuminate\Support\EncodedHtmlString($stammdaten['allgemein']['name']); ?></b> · <?php echo new \Illuminate\Support\EncodedHtmlString($stammdaten['allgemein']['abteilung']); ?> · <?php echo new \Illuminate\Support\EncodedHtmlString($stammdaten['ansprechpartner']['name']); ?>

                        <br><?php echo new \Illuminate\Support\EncodedHtmlString($stammdaten['allgemein']['strasse']); ?> · <?php echo new \Illuminate\Support\EncodedHtmlString($stammdaten['allgemein']['plz']); ?> <?php echo new \Illuminate\Support\EncodedHtmlString($stammdaten['allgemein']['ort']); ?> · Tel. <a href="tel:<?php echo new \Illuminate\Support\EncodedHtmlString(preg_replace('/\D+/', '', $stammdaten['ansprechpartner']['telefon'])); ?>"><?php echo new \Illuminate\Support\EncodedHtmlString($stammdaten['ansprechpartner']['telefon']); ?></a>
                        <br>E-Mail: <a href="mailto:<?php echo new \Illuminate\Support\EncodedHtmlString($stammdaten['ansprechpartner']['email']); ?>"><?php echo new \Illuminate\Support\EncodedHtmlString($stammdaten['ansprechpartner']['email']); ?></a> · <a href="<?php echo new \Illuminate\Support\EncodedHtmlString($stammdaten['allgemein']['web']); ?>"><?php echo new \Illuminate\Support\EncodedHtmlString($stammdaten['allgemein']['web']); ?></a>
                        <br>Werkleitung: <?php echo new \Illuminate\Support\EncodedHtmlString($stammdaten['allgemein']['leitung']); ?> · Sitz: <?php echo new \Illuminate\Support\EncodedHtmlString($stammdaten['allgemein']['sitz']); ?>; Registergericht: <?php echo new \Illuminate\Support\EncodedHtmlString($stammdaten['allgemein']['registergericht']); ?>

                    </p>
                </td>
            </tr>
        </table>
    </td>
</tr><?php /**PATH /Users/michaelbenker/dev/markt/resources/views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>