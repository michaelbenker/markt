<?php $__env->startComponent('mail::message'); ?>
# Ihre Buchungsanfrage

Wir haben Ihre Buchungsanfrage erhalten und werden uns in Kürze bei Ihnen melden.

**Markt:** <?php echo new \Illuminate\Support\EncodedHtmlString($anfrage->markt->name ?? '-'); ?>

<?php if($anfrage->markt && $anfrage->markt->termine && $anfrage->markt->termine->count()): ?>
(<?php echo new \Illuminate\Support\EncodedHtmlString($anfrage->markt->termine->map(fn($t) => \Carbon\Carbon::parse($t->start)->format('d.m.Y'))->join(', ')); ?>)
<?php endif; ?>

**Name:** <?php echo new \Illuminate\Support\EncodedHtmlString($anfrage->anrede ? $anfrage->anrede . ' ' : ''); ?><?php echo new \Illuminate\Support\EncodedHtmlString($anfrage->vorname); ?> <?php echo new \Illuminate\Support\EncodedHtmlString($anfrage->nachname); ?>

**E-Mail:** <?php echo new \Illuminate\Support\EncodedHtmlString($anfrage->email); ?>


**Warenangebot:**
<?php if(is_array($anfrage->warenangebot)): ?>
- <?php echo new \Illuminate\Support\EncodedHtmlString(implode(", ", $anfrage->warenangebot)); ?>

<?php else: ?>
- <?php echo new \Illuminate\Support\EncodedHtmlString($anfrage->warenangebot); ?>

<?php endif; ?>

**Stand:**
<?php $stand = $anfrage->stand; ?>
<?php if(is_array($stand)): ?>
- Art: <?php echo new \Illuminate\Support\EncodedHtmlString($stand['art'] ?? '-'); ?>

- Länge: <?php echo new \Illuminate\Support\EncodedHtmlString($stand['laenge'] ?? '-'); ?> m
- Fläche: <?php echo new \Illuminate\Support\EncodedHtmlString($stand['flaeche'] ?? '-'); ?> m²
<?php endif; ?>

<?php if($anfrage->bemerkung): ?>
**Bemerkung:**
<?php echo new \Illuminate\Support\EncodedHtmlString($anfrage->bemerkung); ?>

<?php endif; ?>

Bei Rückfragen antworten Sie einfach auf diese E-Mail.

Viele Grüße
Ihr Markt-Team
<?php echo $__env->renderComponent(); ?><?php /**PATH /Users/michaelbenker/dev/markt/resources/views/emails/anfrage/bestaetigung.blade.php ENDPATH**/ ?>