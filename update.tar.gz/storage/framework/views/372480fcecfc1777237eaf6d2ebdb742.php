<?php ($a = $this->record); ?>
<?php if (isset($component)) { $__componentOriginalbe23554f7bded3778895289146189db7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe23554f7bded3778895289146189db7 = $attributes; } ?>
<?php $component = Filament\View\LegacyComponents\Page::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Filament\View\LegacyComponents\Page::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal9b945b32438afb742355861768089b04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b945b32438afb742355861768089b04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <dl class="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
            <dl class="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2">
                <dt class="font-semibold">Firma</dt>
                <dd><?php echo e($a->firma); ?></dd>

                <dt class="font-semibold">Name</dt>
                <dd><?php echo e($a->nachname); ?>, <?php echo e($a->vorname); ?></dd>

                <dt class="font-semibold">Anschrift</dt>
                <dd><?php echo e($a->strasse); ?> <?php echo e($a->hausnummer); ?></dd>

                <dt class="font-semibold">Ort</dt>
                <dd><?php echo e($a->plz); ?> <?php echo e($a->ort); ?> (<?php echo e($a->land); ?>)</dd>

                <dt class="font-semibold">Telefon</dt>
                <dd><?php echo e($a->telefon); ?></dd>

                <dt class="font-semibold">E-Mail</dt>
                <dd><?php echo e($a->email); ?></dd>

                <dt class="font-semibold">Stand</dt>
                <dd>
                    <!--[if BLOCK]><![endif]--><?php if(is_array($a->stand)): ?>
                    Art: <?php echo e($a->stand['art'] ?? '-'); ?>, Länge: <?php echo e($a->stand['laenge'] ?? '-'); ?>, Fläche: <?php echo e($a->stand['flaeche'] ?? '-'); ?>

                    <?php else: ?>
                    <?php echo e($a->stand); ?>

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </dd>

                <dt class="font-semibold">Warenangebot</dt>
                <dd>
                    <!--[if BLOCK]><![endif]--><?php if(is_array($a->warenangebot)): ?>
                    <?php echo e(implode(', ', $a->warenangebot)); ?>

                    <?php else: ?>
                    <?php echo e($a->warenangebot); ?>

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </dd>

                <dt class="font-semibold">Herkunft</dt>
                <dd>
                    <!--[if BLOCK]><![endif]--><?php if(is_array($a->herkunft)): ?>
                    Eigenfertigung: <?php echo e($a->herkunft['eigenfertigung'] ?? '-'); ?>%,
                    Industrieware (nicht Entwicklungsländer): <?php echo e($a->herkunft['industrieware_nicht_entwicklungslaender'] ?? '-'); ?>%,
                    Industrieware (Entwicklungsländer): <?php echo e($a->herkunft['industrieware_entwicklungslaender'] ?? '-'); ?>%
                    <?php else: ?>
                    <?php echo e($a->herkunft); ?>

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </dd>

                <dt class="font-semibold">Bereits ausgestellt?</dt>
                <dd><?php echo e($a->bereits_ausgestellt ? 'Ja' : 'Nein'); ?></dd>

                <dt class="font-semibold">Bemerkung</dt>
                <dd><?php echo e($a->bemerkung); ?></dd>

                <dt class="font-semibold text-gray-500 text-sm">Erstellt am</dt>
                <dd class="text-gray-500 text-sm"><?php echo e($a->created_at?->format('d.m.Y H:i')); ?></dd>
            </dl>
            <div>
                <dd>
                    <!--[if BLOCK]><![endif]--><?php if(count($this->matchingAussteller)): ?>
                    <div class="grid gap-4 mb-4">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->matchingAussteller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($aus = $match['aussteller']); ?>
                        <div class="border rounded-lg p-4 bg-gray-50">
                            <div class="font-bold text-lg mb-1"><?php echo e($aus->firma ?? '-'); ?></div>
                            <div><?php echo e($aus->name); ?>, <?php echo e($aus->vorname); ?></div>
                            <div><?php echo e($aus->email); ?> | <?php echo e($aus->telefon); ?></div>
                            <div><?php echo e($aus->plz); ?> <?php echo e($aus->ort); ?></div>
                            <div class="text-xs text-gray-500 mt-1">Treffer: <?php echo e(implode(', ', $match['criteria'])); ?></div>
                            <div class="mt-2 flex flex-col gap-2">
                                <!--[if BLOCK]><![endif]--><?php if($match['perfect']): ?>
                                <form wire:submit.prevent="createBuchung(<?php echo e($aus->id); ?>)">
                                    <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'success','class' => 'w-full','type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'success','class' => 'w-full','type' => 'submit']); ?>Buchung erzeugen <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
                                </form>
                                <?php else: ?>
                                <form wire:submit.prevent="updateAusstellerUndBuchung(<?php echo e($aus->id); ?>)">
                                    <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'warning','class' => 'w-full','type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'warning','class' => 'w-full','type' => 'submit']); ?>Aussteller-Daten aktualisieren und Buchung erzeugen <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
                                </form>
                                <form wire:submit.prevent="buchungMitDatenUebernehmen(<?php echo e($aus->id); ?>)">
                                    <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'success','class' => 'w-full','type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'success','class' => 'w-full','type' => 'submit']); ?>Buchung erzeugen (Aussteller-Daten werden übernommen) <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
                                </form>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <?php else: ?>
                    <div class="text-gray-500 mb-4">Kein passender Aussteller gefunden.</div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <form wire:submit.prevent="ausstellerNeuUndBuchung()">
                        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'primary','class' => 'w-full mt-4','type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'primary','class' => 'w-full mt-4','type' => 'submit']); ?>Aussteller neu anlegen und Buchung erzeugen <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
                    </form>
                </dd>
            </div>
        </dl>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b945b32438afb742355861768089b04)): ?>
<?php $attributes = $__attributesOriginal9b945b32438afb742355861768089b04; ?>
<?php unset($__attributesOriginal9b945b32438afb742355861768089b04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b945b32438afb742355861768089b04)): ?>
<?php $component = $__componentOriginal9b945b32438afb742355861768089b04; ?>
<?php unset($__componentOriginal9b945b32438afb742355861768089b04); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe23554f7bded3778895289146189db7)): ?>
<?php $attributes = $__attributesOriginalbe23554f7bded3778895289146189db7; ?>
<?php unset($__attributesOriginalbe23554f7bded3778895289146189db7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe23554f7bded3778895289146189db7)): ?>
<?php $component = $__componentOriginalbe23554f7bded3778895289146189db7; ?>
<?php unset($__componentOriginalbe23554f7bded3778895289146189db7); ?>
<?php endif; ?><?php /**PATH /Users/michaelbenker/dev/markt/resources/views/filament/resources/anfrage-resource/pages/view-anfrage.blade.php ENDPATH**/ ?>