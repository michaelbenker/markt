<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/michaelbenker/dev/markt/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>