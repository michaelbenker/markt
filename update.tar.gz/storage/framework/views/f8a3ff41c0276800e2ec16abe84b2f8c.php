<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Markt App</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="bg-gray-50 text-gray-900 h-screen grid m-0" style="grid-template-rows: 70px auto 60px;">
    <header class="bg-gray-100 flex items-center justify-center">
        <a href="/" class="inline-block">
            <img src="/images/vff_icon.svg" alt="Veranstaltungsforum Fürstenfeld Logo" class="h-12">
        </a>
    </header>
    <main>
        <?php echo e($slot); ?>

    </main>
    <footer class="px-6 text-xs text-gray-600 bg-gray-100  flex items-center justify-center">
        <div class="text-center">
            <b><?php echo e($stammdaten['allgemein']['name']); ?></b> · <?php echo e($stammdaten['allgemein']['abteilung']); ?> · <?php echo e($stammdaten['ansprechpartner']['name']); ?>

            <br>Tel. <a href="tel:<?php echo e(preg_replace('/\D+/', '', $stammdaten['ansprechpartner']['telefon'])); ?>"><?php echo e($stammdaten['ansprechpartner']['telefon']); ?></a> · E-Mail: <a href="mailto:<?php echo e($stammdaten['ansprechpartner']['email']); ?>"><?php echo e($stammdaten['ansprechpartner']['email']); ?></a>
        </div>
    </footer>
</body>

</html><?php /**PATH /Users/michaelbenker/dev/markt/resources/views/components/layout.blade.php ENDPATH**/ ?>