<?php echo e($slot); ?>

<?php /**PATH /Users/michaelbenker/dev/markt/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>