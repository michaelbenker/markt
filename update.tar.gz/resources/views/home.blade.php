<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>Markt-App</title>
</head>

<body>
    <h1>Willkommen zur Markt-App</h1>
    <p>Hier entsteht eine Anwendung zur Verwaltung von Ausstellern und Märkten.</p>
</body>

</html>