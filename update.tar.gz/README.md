# Markt App

php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear
php artisan migrate:fresh --seed

## Migration

php artisan make:migration name_der_migration

## Deployment

chmod +x deploy.sh
