<?php

namespace App\Filament\Resources\SubkategorieResource\Pages;

use App\Filament\Resources\SubkategorieResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSubkategorie extends CreateRecord
{
    protected static string $resource = SubkategorieResource::class;
}
