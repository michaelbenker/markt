<?php

namespace App\Filament\Resources\KategorieResource\Pages;

use App\Filament\Resources\KategorieResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKategorie extends CreateRecord
{
    protected static string $resource = KategorieResource::class;
}
