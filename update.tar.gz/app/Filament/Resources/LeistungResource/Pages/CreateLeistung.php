<?php

namespace App\Filament\Resources\LeistungResource\Pages;

use App\Filament\Resources\LeistungResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLeistung extends CreateRecord
{
    protected static string $resource = LeistungResource::class;
}
