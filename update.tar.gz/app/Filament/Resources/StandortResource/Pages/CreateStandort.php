<?php

namespace App\Filament\Resources\StandortResource\Pages;

use App\Filament\Resources\StandortResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateStandort extends CreateRecord
{
    protected static string $resource = StandortResource::class;
}
