<?php

namespace App\Filament\Resources\MarktResource\Pages;

use App\Filament\Resources\MarktResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMarkt extends CreateRecord
{
    protected static string $resource = MarktResource::class;
}
