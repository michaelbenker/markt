<?php

namespace App\Filament\Resources\BuchungResource\Pages;

use App\Filament\Resources\BuchungResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBuchung extends CreateRecord
{
    protected static string $resource = BuchungResource::class;
}
