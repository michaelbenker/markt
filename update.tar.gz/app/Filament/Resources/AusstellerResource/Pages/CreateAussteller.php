<?php

namespace App\Filament\Resources\AusstellerResource\Pages;

use App\Filament\Resources\AusstellerResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAussteller extends CreateRecord
{
    protected static string $resource = AusstellerResource::class;
}
